package cs3500.marblesolitaire.model.hw02;

enum Slot {
  Marble,
  Empty,
  Invalid
}
